
# MEXC Trader Bot (Telegram)
Бот принимает сигналы в формате:
SIG BUY SOL 20USDT @MKT TP=212 SL=188
R: короткая причина

Переменные окружения (Railway → Variables):
  TELEGRAM_TOKEN - токен бота
  ALLOWED_USER_ID - ваш Telegram ID
  MEXC_API_KEY - API Key MEXC
  MEXC_SECRET_KEY - Secret Key MEXC
  PAPER_MODE - true/false (бумажный режим)
  MAX_ORDER_USDT - лимит на одну сделку
